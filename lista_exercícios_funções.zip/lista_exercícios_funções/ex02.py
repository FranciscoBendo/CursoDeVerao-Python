def minerar(mineral):
    print(f"Você minerou {mineral}!")
minerar("diamante")