def derrotar_mob(nivel):  #O que o parâmetro tipo deveria fazer?
    return nivel * 5

xp = derrotar_mob(10)
print(xp)