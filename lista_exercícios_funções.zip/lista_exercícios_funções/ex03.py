def coletar_item():
    return "Espada de ferro"

item = coletar_item()

print(item)