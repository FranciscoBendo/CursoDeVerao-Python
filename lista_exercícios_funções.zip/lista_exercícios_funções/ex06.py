class Mob:
    nome = "creeper"
    vida = 20

    def status():
        print(Mob.nome, Mob.vida)

Mob.status()