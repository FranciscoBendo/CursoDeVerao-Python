class Creeper:
    vida = 20

    def explodir():
        print("BOOM")

Creeper.explodir()