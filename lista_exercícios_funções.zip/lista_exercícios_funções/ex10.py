class Inventario:
    lista = []

    def adicionar_item(item):
        Inventario.lista.append(item)
        print(f"O item {item} foi adicionado!")

    def remover_item(item):
        for c in Inventario.lista:
            if item in Inventario.lista:
                Inventario.lista.remove(item)
                print(f"O item {item} foi removido!")
                break
            else:
                print("Item não encontrado")
                break
    
    def mostrar_inventario():
        print(Inventario.lista)

Inventario.adicionar_item("Banana")
Inventario.adicionar_item("Batata")
Inventario.adicionar_item("Tomate")

Inventario.mostrar_inventario()

Inventario.remover_item("Tomate")

Inventario.mostrar_inventario()

Inventario.remover_item("Pimentão")
