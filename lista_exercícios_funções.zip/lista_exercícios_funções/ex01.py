def minerar_carvao():
    print("Você minerou carvão!")

minerar_carvao()