def construir_porta(bloco, quantidade):
    print(f"Você construiu uma porta com {quantidade} blocos de {bloco}.")

construir_porta("madeira", 6)