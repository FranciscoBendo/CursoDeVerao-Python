class Mob:
    vida = 10

class Jogador:
    def atacar(Mob):
        Mob.vida -= 10

print(Mob.vida)
print("ATAQUE AAAAA")
Jogador.atacar(Mob)
print(Mob.vida)