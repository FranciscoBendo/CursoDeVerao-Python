class Bloco:
    tipo = "terra"
    quebravel = False

    def quebrar(quebravel):
        if quebravel == True:
            print("Quebrou")
        else:
            print("Não quebrou")

Bloco.quebrar(Bloco.quebravel)