arsenal = ["Classic", "Stinger", "Spectre", "Phantom", "Operator"]

print(f"{arsenal[0]}, {arsenal[-1]}")

print(f"arsenal: {arsenal[0]}, {arsenal[-1]}")