carteira = {
    "creditos" : 800
}

carteira["creditos"] += 3000

print(carteira)