armas = {
    "pistola": 1000,
    "faca": 500,
    "fuzil": 2000,
    "sniper": 5000
}

lista = []

for arma, preco in armas.items():
    if preco < 2000:
        lista = arma
print(lista)