abates_por_round = [3, 1, 0, 5, 2, 1]
print(abates_por_round)

abates_por_round.sort(reverse=True)
print(abates_por_round)
