chat_global = ["ruim", "lixo", "feio", "bananão"]
print(chat_global)

chat_global.clear()
print(chat_global)