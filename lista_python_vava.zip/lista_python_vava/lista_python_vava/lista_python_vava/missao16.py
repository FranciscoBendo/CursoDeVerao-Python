jogadores = [
    {" nome ": " Raze ", " kills ": 25 , " deaths ": 100} ,
    {" nome ": " Cypher ", " kills ": 120 , " deaths ": 15} ,
    {" nome ": " Jett ", " kills ": 30 , " deaths ": 50}
]

bons_jogadores = [j[" nome "] for j in jogadores if j[" kills "] > j[" deaths "]]
print(bons_jogadores)