drops = ["Vandal", "Sheriff", "Bucky", "Vandal", "Ghost"]

print(f"Tem {drops.count("Vandal")} Vandal no chão")