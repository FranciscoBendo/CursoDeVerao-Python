dano_base = [10, 20, 30, 40]
print(dano_base)

dano_venenoso = [1.5 * c for c in dano_base]
print(dano_venenoso)