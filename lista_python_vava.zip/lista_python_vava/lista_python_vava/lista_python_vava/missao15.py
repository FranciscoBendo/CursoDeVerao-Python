armas = {
    "pistola": 1000,
    "faca": 500,
    "fuzil": 2000,
    "sniper": 5000
}

lista = []

#AGR VC CONSEGUE PORRA