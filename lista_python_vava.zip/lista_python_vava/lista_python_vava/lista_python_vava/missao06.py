skins = {
    "Vandal" : "Pistola",
    "Banana" : "Fuzil"
}

chaves = skins.keys()

if "Vandal" in chaves:
    print(True)
else:
    print(False)