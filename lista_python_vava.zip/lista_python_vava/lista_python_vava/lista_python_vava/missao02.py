sova = {
    "Q" : "Flexa de Choque",
    "E" : "Rastreador",
    "C" : "Drone Coruja",
    "X" : "Fúria do Caçador"
}

print(sova)