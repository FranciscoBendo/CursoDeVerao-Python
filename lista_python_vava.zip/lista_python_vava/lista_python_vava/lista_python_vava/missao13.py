lista_A = ["Joaozin", "fulanina", "siclano"]
lista_B = ["Ronaldinho soccer", "Mineirinho Ultra-Adventures"]
print(lista_A)
print(lista_B)
lista_A.extend(lista_B)
print(lista_A)