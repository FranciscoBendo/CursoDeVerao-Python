estatisticas_mapas = {
    "Bind" : {"vitorias": 1000, "derrotas" : 1},
    "Ice Box": {"vitorias" : 10, "derrotas": 1500}
}
print(estatisticas_mapas.items())

estatisticas_mapas["Haven"] = {"vitorias": 100, "derrotas": 10}
print(estatisticas_mapas.items())

estatisticas_mapas["Bind"]["vitorias"] += 1
print(estatisticas_mapas.items())