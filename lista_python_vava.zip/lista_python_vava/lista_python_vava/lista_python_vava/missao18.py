agentes_funcoes = {"Jett" : "Duelista", "Sova" : "Iniciador"}

novo_dict = {nome: len(func) for nome, func in agentes_funcoes.items()}

print(novo_dict)