status = {"K": 15, "D": 10, "A": 5}

for chaves, valores in status.items():
    print(f"Status: {chaves} -> Valores: {valores}")