dez_melhores = ["jogador1", "jogador2", "jogador3", "jogador4", "jogador5", "jogador6", "jogador7", "jogador8", "jogador9", "jogador10"]

jogador1, jogador2, jogador3 = dez_melhores[0:3]

print(f"Os três melhores jogadores são: {jogador1}, {jogador2} e {jogador3}")