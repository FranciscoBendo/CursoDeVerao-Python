agente = {"nome": "Neon", "nivel": 22}

print(agente.get("Elo", "Sem Rank"))