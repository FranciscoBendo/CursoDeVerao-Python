habilidade = ["Smoke", "Flash", "Heal"]
print(habilidade)

ultima_usada = habilidade.pop(-1)
print(ultima_usada)