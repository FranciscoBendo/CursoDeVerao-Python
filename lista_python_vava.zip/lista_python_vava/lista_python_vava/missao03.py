fila = ["Jett", "Sage"]
print(fila)

fila.insert(0, "Phoenix")
print(fila)
