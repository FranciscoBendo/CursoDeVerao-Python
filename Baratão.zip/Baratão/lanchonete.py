class Cardapio:

    def __init__(self):

        self.lista_cardapio = []  

    def adicionar_no_cardapio(self, nome, preco):

        prato = {
            "nome" : nome,
            "preco" : preco
        }

        self.lista_cardapio.append(prato)
        print("Item adicionado com sucesso!")

    def mostrar_cardapio(self):
        for prato in self.lista_cardapio:
            print("-" * 30)
            print(f"Prato: {prato.values()} \nPreço: {prato.values()}")

    def remover_do_cardapio(self, nome):
        if nome not in self.lista_cardapio[prato]:
            print("Não existe.")
        else:
            for c in self.lista_cardapio:
                if c["nome"] == nome:
                    self.lista_cardapio[prato.values].remove(prato)

c = Cardapio()

c.adicionar_no_cardapio("Macarrão", 10)
c.mostrar_cardapio()
c.remover_do_cardapio("Macarrão")
        