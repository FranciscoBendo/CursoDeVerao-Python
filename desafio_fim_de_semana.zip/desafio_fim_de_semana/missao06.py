nivel_acesso = int(input("Digite o nível de acesso: "))
is_spy = False

if nivel_acesso > 5 and not (is_spy):
    print("Passou")
else:
    print("Não passou")