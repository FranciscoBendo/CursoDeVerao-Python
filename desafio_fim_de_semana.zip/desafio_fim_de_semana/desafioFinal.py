for i in range(1, 11):
    if i % 2 == 0:
        print(f"O habitante {i}, sobreviveu!")
    else:
        print(f"O habitante {i}, MORREU!")