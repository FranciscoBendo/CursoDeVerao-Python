codinome = input("Qual é o seu codinome? ")

print(f"Acesso liberado para o agente {codinome}.")