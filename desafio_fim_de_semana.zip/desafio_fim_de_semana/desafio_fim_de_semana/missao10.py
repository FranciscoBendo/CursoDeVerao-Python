for i in range(1, 11):
    if i == 5:
        print(f"Round {i}, descanço!")
    elif i == 8:
        print(f"Round {i}, Caveira vermelha fugiu!")
        break
    else:
        print(f"Round {i}, luta!")