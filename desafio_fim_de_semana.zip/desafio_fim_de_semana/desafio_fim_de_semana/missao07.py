distancia = float(input("Digite a distância do disparo em metros: "))

if distancia < 10:
    print("Disparo curto")
elif distancia > 50:
    print("Disparo longo")
else:
    print("Disparo médio")