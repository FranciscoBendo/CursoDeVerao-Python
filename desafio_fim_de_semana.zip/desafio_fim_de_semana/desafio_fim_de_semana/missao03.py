forca_base = 5000
multiplicador_raiva = 20
soco_final = forca_base * multiplicador_raiva

print(soco_final)