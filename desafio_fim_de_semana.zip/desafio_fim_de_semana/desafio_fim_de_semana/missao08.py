x = 0

while x < 5:
    print("Dormammu, eu vim barganhar...")
    x += 1