nome = 'Steve Rogers'
idade_tecnica = 105
altura = 1.88
possui_escudo = True

print(type(nome))
print(type(idade_tecnica))
print(type(altura))
print(type(possui_escudo))