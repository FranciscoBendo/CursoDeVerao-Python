nivel_dignidade = int(input("Você é digno? (0 - 100): "))

if nivel_dignidade >= 90:
    print("Você levantou o martelo!")
else:
    print("Você não é digno.")