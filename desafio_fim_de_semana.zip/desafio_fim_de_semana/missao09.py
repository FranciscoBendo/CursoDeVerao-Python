for c in range(5):
    print(f"Disparo {c + 1}!")